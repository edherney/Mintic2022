package co.gov.mintic.contabilidad.ingresosegresos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IngresosegresosApplicationTests {

	@Test
	void contextLoads() {
	}

}
