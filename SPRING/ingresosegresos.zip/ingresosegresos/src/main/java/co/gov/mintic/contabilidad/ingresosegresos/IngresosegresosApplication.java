package co.gov.mintic.contabilidad.ingresosegresos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngresosegresosApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngresosegresosApplication.class, args);
	}

}
